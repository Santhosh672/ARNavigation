using System;
using UnityEngine;

[Serializable]
public class TargetFacade : MonoBehaviour {
    public string Name;
    public int FloorNumber;
}
