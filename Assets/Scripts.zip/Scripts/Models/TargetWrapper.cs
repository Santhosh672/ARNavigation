using System;

[Serializable]
public class TargetWrapper {
    public Target[] TargetList;
}
